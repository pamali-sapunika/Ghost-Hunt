package com.example.mygame

//GameTask.kt
interface GameTask {
    fun closeGame(mScore:Int)
    fun closeGame2(mScore:Int)
}