package com.example.mygame

//MainActivity.kt
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : AppCompatActivity(),GameTask {
    lateinit var rootLayout : LinearLayout
    lateinit var layout2 : LinearLayout
    lateinit var startBtn1 : Button
    lateinit var startBtn2 : Button
    lateinit var mGameView : GameView
    lateinit var mGameView2 : GameView2
    lateinit var score : TextView
    lateinit var image: ImageView
    lateinit var gametext: TextView
    lateinit var highscore: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        startBtn1 = findViewById(R.id.startBtn1)
        startBtn2 = findViewById(R.id.button)
        rootLayout = findViewById(R.id.rootLayout)
        layout2 = findViewById(R.id.layout2)
        score = findViewById(R.id.score)
        image = findViewById(R.id.image)
        gametext = findViewById(R.id.gametext)
        highscore = findViewById(R.id.highscore)

        startBtn1.setOnClickListener{
            mGameView = GameView(this, this) // Initialize the GameView here
            mGameView.setBackgroundResource(R.drawable.nightsky3)
            rootLayout.addView(mGameView)
            startBtn1.visibility = View.GONE
            layout2.visibility = View.GONE
            score.visibility = View.GONE
            image.visibility = View.GONE
            gametext.visibility = View.GONE
            startBtn2.visibility = View.GONE
        }

        startBtn2.setOnClickListener{
            mGameView = GameView(this, this) // Initialize the GameView here
            mGameView.setBackgroundResource(R.drawable.sky1)
            rootLayout.addView(mGameView)
            startBtn1.visibility = View.GONE
            score.visibility = View.GONE
            image.visibility = View.GONE
            gametext.visibility = View.GONE
            startBtn2.visibility = View.GONE
            layout2.visibility = View.GONE
        }
    }



    override fun closeGame(mScore: Int) {
        val currentHighScore = HighScoreManager.getHighScore()
        if (mScore > currentHighScore) {
            HighScoreManager.updateHighScore(mScore)
        }
        score.text = "Score : $mScore"
        highscore.text = "High Score: ${HighScoreManager.getHighScore()}"
        HighScoreManager.updateHighScore(mScore)
        rootLayout.removeView(mGameView)
        startBtn1.visibility = View.VISIBLE
        score.visibility = View.VISIBLE
        image.visibility = View.VISIBLE
        gametext.visibility = View.GONE
        startBtn2.visibility = View.VISIBLE
        layout2.visibility = View.VISIBLE
    }

    override fun closeGame2(mScore: Int) {
        val currentHighScore = HighScoreManager.getHighScore()
        if (mScore > currentHighScore) {
            HighScoreManager.updateHighScore(mScore)
        }
        score.text = "Score : $mScore"
        highscore.text = "High Score: ${HighScoreManager.getHighScore()}"
        HighScoreManager.updateHighScore(mScore)
        rootLayout.removeView(mGameView2)
        startBtn1.visibility = View.VISIBLE
        score.visibility = View.VISIBLE
        image.visibility = View.VISIBLE
        gametext.visibility = View.GONE
        startBtn2.visibility = View.VISIBLE
        layout2.visibility = View.VISIBLE
    }

}