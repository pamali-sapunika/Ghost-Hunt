object HighScoreManager {
    private var highScore = 0

    fun updateHighScore(score: Int) {
        if (score > highScore) {
            highScore = score
            // Log the updated high score
            println("High score updated: $highScore")
        }
    }

    fun getHighScore(): Int {
        return highScore
    }
}
